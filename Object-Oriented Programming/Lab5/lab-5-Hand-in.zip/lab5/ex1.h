#include <stdlib.h>
#ifndef ex1
#define ex1

template <typename T>
const T pi =T(3.1415926535897932385L);
template <typename T>
T inPiRange(T input)
{
    return (input<pi<T>);
}
    

#endif
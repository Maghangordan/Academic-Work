
#include "lists.h"


int main() {
	listmenu();

	stack();
	queue();

	return 0;
}


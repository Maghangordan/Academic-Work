#include "sortingAlg.h"
#include "utilities.h"


int main()
{	
	
	ex_4();

	tester();

	return 0;
	
}